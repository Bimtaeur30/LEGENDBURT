using DG.Tweening;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class PartsEquip_UI : MonoBehaviour
{
    // ī�� �����ϰ� ����°� ������.
    // ParsCardSelector_UI���� �������� ActivateEquipParts �������.
    [Header("Events")]
    [SerializeField] private EventChannelSO playerChannel;
    [Header("UI")]
    [SerializeField] private CanvasGroup[] hideGroups;
    [SerializeField] private CanvasGroup canvasGroup;
    [SerializeField] private CanvasGroup equipBtnGroup;
    [SerializeField] private Image partsIcon;
    [SerializeField] private Button equipBtn_L;
    [SerializeField] private Button equipBtn_R;
    private bool onEquipEvent = false;
    private PartsDataSO myData;
    private DG.Tweening.Sequence sequence;

    private void Awake()
    {
        equipBtn_L.onClick.AddListener(() => HandleEquipBtnPressed(PartsJointPos.FirstSlot));
        equipBtn_R.onClick.AddListener(() => HandleEquipBtnPressed(PartsJointPos.SecondSlot));
        sequence = DOTween.Sequence();
    }

    private void HandleEquipBtnPressed(PartsJointPos pos)
    {
        Debug.Log(playerChannel);
        Debug.Log(myData);
        Debug.Log(myData?.PartPrefab);
        // ���� ���⼭ �������ָ� �ȴ�.
        DeactivateEquipParts();
        playerChannel.RasiseEvent(PlayerEvents.AttachPartsEvent.Init(myData, pos));
        playerChannel.RasiseEvent(PlayerEvents.OnGameReadyEvent);
    }

    public void ActivateEquipParts(PartsDataSO data)
    {
        myData = data;
        onEquipEvent = true;
        partsIcon.sprite = data.PartsIcon;

        sequence.Join(canvasGroup.DOFade(1f, 1f));
        sequence.Join(equipBtnGroup.DOFade(1f, 1f));
        equipBtnGroup.interactable = true;

        foreach (CanvasGroup c in hideGroups)
            sequence.Join(c.DOFade(0f, 0.5f));
    }

    public void DeactivateEquipParts()
    {
        sequence.Kill();
        canvasGroup.DOFade(0f, 0.5f);
        equipBtnGroup.DOFade(0f, 0.5f);
        equipBtnGroup.interactable = false;

        foreach (CanvasGroup c in hideGroups)
            c.DOFade(1f, 0.5f);
    }

    private void Update()
    {
        if (onEquipEvent)
        {
            partsIcon.rectTransform.position = Mouse.current.position.ReadValue();
        }
    }
}
