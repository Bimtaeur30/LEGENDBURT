using UnityEngine;

[CreateAssetMenu(fileName = "StageDataSO", menuName = "Stage/StageDataSO")]
public class StageDataSO : ScriptableObject
{
    public string StageName = "����";
    public int LimitedTime = 30;
    public Stage StagePrefab;
}
