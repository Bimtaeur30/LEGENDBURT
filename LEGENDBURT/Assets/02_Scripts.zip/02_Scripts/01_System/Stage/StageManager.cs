using System;
using System.Collections.Generic;
using Assets._02_Scripts._01_System.Stage;
using UnityEngine;
using UnityEngine.SceneManagement;

[DefaultExecutionOrder(-100)]
public class StageManager : MonoSingleton<StageManager>
{
    [field:SerializeField] public StageDataSO[] StageData { get; private set; }
    [field:SerializeField] public StageDataSO Tuto_stageData { get; private set; }

    [SerializeField] private EventChannelSO playerChannel;
    [SerializeField] private EventChannelSO stageChannel;

    [field: SerializeField] public int CurrentStageIndex { get; private set; } = -1; // �׽�Ʈ�� 0 �ص���, �����δ� �κ񿡼��� -1����, �������� 1 ���� �� 0�� �����ؾ���.

    public StageDataSO CurrentStageData { get; private set; } = null;
    public PartsDataSO Save_parts1 { get; private set; } = null;
    public PartsDataSO Save_parts2 { get; private set; } = null;
    public List<ArtifactSO> Save_artifactSOs { get; private set; } = new();

    protected override void Awake()
    {
        base.Awake();
        playerChannel.AddListener<AttachPartsEvent>(HandleAttachPartsEvent);
        //playerChannel.AddListener<EquipItemEvent>(HandleEquipItemEvent);

        stageChannel.AddListener<MoveNextStageEvent>(HandleMoveNextStageEvent);
        stageChannel.AddListener<LoadTutorialEvent>(HandleLoadTutorialEvent);
        stageChannel.AddListener<CreateStageSaveDataEvent>(HandleCreateStageSaveDataEvent);
        stageChannel.AddListener<RemoveStageSaveDataEvent>(HandleRemoveStageSaveDataEvent);
    }


    private void OnEnable()
    {
        SceneManager.sceneLoaded += HandleSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= HandleSceneLoaded;
    }

    private void HandleSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (CurrentStageIndex >= 0)
        {
            InitializeStage();
        }
        else if (CurrentStageIndex == -2)
        {
            InitializeTutorial();
        }
    }

    private void OnDestroy()
    {
        playerChannel.RemoveListener<AttachPartsEvent>(HandleAttachPartsEvent);
        //playerChannel.RemoveListener<EquipItemEvent>(HandleEquipItemEvent);

        stageChannel.RemoveListener<MoveNextStageEvent>(HandleMoveNextStageEvent);
        stageChannel.RemoveListener<LoadTutorialEvent>(HandleLoadTutorialEvent);
        stageChannel.RemoveListener<CreateStageSaveDataEvent>(HandleCreateStageSaveDataEvent);
        stageChannel.RemoveListener<RemoveStageSaveDataEvent>(HandleRemoveStageSaveDataEvent);
    }

    private void InitializeStage()
    {
        CurrentStageData = StageData[CurrentStageIndex];
        Stage stage = Instantiate(CurrentStageData.StagePrefab, Vector3.zero, Quaternion.identity);
        stage.Initialize();
    }

    private void InitializeTutorial()
    {
        CurrentStageData = Tuto_stageData;
        Stage stage = Instantiate(CurrentStageData.StagePrefab, Vector3.zero, Quaternion.identity);
        stage.Initialize();
    }

    private void HandleAttachPartsEvent(AttachPartsEvent @event)
    {
        switch(@event.JointPos)
        {
            case PartsJointPos.FirstSlot:
                Save_parts1 = @event.Parts;
                break;
            case PartsJointPos.SecondSlot:
                Save_parts2 = @event.Parts;
                break;
        }
    }

    private void HandleMoveNextStageEvent(MoveNextStageEvent @event)
    {
        if (CurrentStageIndex >= StageData.Length - 1)
        {
            CurrentStageIndex = -1;
            Save_parts1 = null;
            Save_parts2 = null;
            Save_artifactSOs.Clear();
            SceneChangeManager.Instance.ChangeScene("02_Ending");

        }
        else
        {
            CurrentStageIndex++;
            Save_parts1 = @event.FirstParts;
            Save_parts2 = @event.SecondParts;
            Save_artifactSOs = @event.ArtifactLIst;

            SceneChangeManager.Instance.ChangeScene("01_MainGame");

        }
    }
    private void HandleCreateStageSaveDataEvent(CreateStageSaveDataEvent @event)
    {
        CurrentStageIndex = 0;
    }
    private void HandleRemoveStageSaveDataEvent(RemoveStageSaveDataEvent @event)
    {
        CurrentStageIndex = -1; // �׽�Ʈ�� 0 �صа���, -1�� ���ľ���
        Save_parts1 = null;
        Save_parts2 = null;
        Save_artifactSOs?.Clear();
        SceneChangeManager.Instance.ChangeScene("03_Menu");
    }
    private void HandleLoadTutorialEvent(LoadTutorialEvent @event)
    {
        CurrentStageIndex = -2;
        Save_parts1 = null;
        Save_parts2 = null;
        Save_artifactSOs?.Clear();
        SceneChangeManager.Instance.ChangeScene("04_Tutorial");

    }
}