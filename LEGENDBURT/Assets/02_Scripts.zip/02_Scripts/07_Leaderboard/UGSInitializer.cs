using Unity.Services.Authentication;
using Unity.Services.Core;
using UnityEngine;

public class UGSInitializer : MonoSingleton<UGSInitializer> // �̱������� ����
{
    protected override void Awake()
    {
        base.Awake(); // MonoSingleton�� �ߺ� �ν��Ͻ� �ı� ���� Ȱ��
        InitializeUGS();
    }

    private async void InitializeUGS()
    {
        await UnityServices.InitializeAsync();
        if (!AuthenticationService.Instance.IsSignedIn)
        {
            await AuthenticationService.Instance.SignInAnonymouslyAsync();
            if (AuthenticationService.Instance.IsSignedIn && AuthenticationService.Instance.IsAuthorized)
            {
                Debug.Log("UGS �α��� �Ϸ�");
            }
        }
    }
}